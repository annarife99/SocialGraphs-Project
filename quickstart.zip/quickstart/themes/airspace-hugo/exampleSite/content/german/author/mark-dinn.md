---
title: "Mark Dinn"
email: "email2@example.org"
bg_image: "images/feature-bg.jpg"
draft: false
social:
  - icon : "fab fa-facebook" #https://fontawesome.com/v5.15/icons
    link : "#"
  - icon : "fab fa-twitter" #https://fontawesome.com/v5.15/icons
    link : "#"
  - icon : "fab fa-pinterest" #https://fontawesome.com/v5.15/icons
    link : "#"
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet vulputate augue. Duis auctor lacus id vehicula gravida. Nam suscipit vitae purus et laoreet.
Donec nisi dolor, consequat vel pretium id, auctor in dui. Nam iaculis, neque ac ullamcorper.
