---
title: "Graphs"
date: 2021-11-27T18:04:47+01:00
draft: false
---

var trace1 = {
  x: [1, 2, 3, 4],
  y: [10, 15, 13, 17],
  type: 'scatter'
};

var trace2 = {
  x: [1, 2, 3, 4],
  y: [16, 5, 11, 9],
  type: 'scatter'
};

var data = [trace1, trace2];

Plotly.newPlot('myDiv', data);


<div class="figure">
<div class="figure-plot" id="{{ .Get 0 }}">
	Code could not finish, this are some reasons why this happen.
	- Plot name not defined. The first parameter of the shortcode is the name.
	- There is a syntax error. check browser console.
</div>
<script>
  function draw(){
	test = document.getElementById("{{ .Get 0 }}");
	if (test == null){
		console.log("The plot name is not defined")
		return
	}

	fig = null
	{{ .Inner | safeJS }}

	if (!fig) {
		test.innerText = "ERROR: fig variable is not defined"
		return
	}
	test.innerText = null
	Plotly.plot(test ,fig);
  }
  draw()
</script>
</div>

{{/*% plot plot2 %*/}}
var trace1 = {
  x: [1, 2, 3, 4],
  y: [10, 15, 13, 17],
  type: 'scatter'
};

var trace2 = {
  x: [1, 2, 3, 4],
  y: [16, 5, 11, 9],
  type: 'scatter'
};

data = [trace1, trace2];
fig = {
  data: data
}
{{/*% /plot %*/}}



![image description](Images/song_labMT.png)

![image description](/Images/songs_VADER.png)